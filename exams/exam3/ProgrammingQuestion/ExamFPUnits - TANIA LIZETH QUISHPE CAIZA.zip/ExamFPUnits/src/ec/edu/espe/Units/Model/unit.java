/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espe.Units.Model;

/**
 *
 * @author 10
 */
public class unit {

    public unit(String Onedayhas, String Onehourhas, String Oneminutehas, String Howmanyminutesis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
