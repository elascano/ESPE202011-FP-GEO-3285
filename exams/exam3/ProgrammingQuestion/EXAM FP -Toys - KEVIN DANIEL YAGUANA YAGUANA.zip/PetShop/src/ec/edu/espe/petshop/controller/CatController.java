/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espe.petshop.controller;

import ec.edu.espe.petshop.model.Cat;
import utils.FileManager;

/**
 *
 * @author Thomas Chavez
 */
public class CatController {
    public void save(Cat cat){
        String data = cat.getName()+ ";" + cat.getColor() + ";" + cat.getHairtype() + ";" + cat.getRaze() + ";" + cat.getAge();
        FileManager.save(data, "cats");
        
        
    }
    public String read() {

        String data;
        data = FileManager.read("cats");
        return data;
    }
    }

