/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espe.petshop.model;

/**
 *
 * @author Thomas Chavez
 */
public class Cat {
    private String name;
    private String color;
    private String raze;
    private int age;
    private String hairtype;

    public Cat(String name, String color, String raze, int age, String hairtype) {
        this.name = name;
        this.color = color;
        this.raze = raze;
        this.age = age;
        this.hairtype = hairtype;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return the raze
     */
    public String getRaze() {
        return raze;
    }

    /**
     * @param raze the raze to set
     */
    public void setRaze(String raze) {
        this.raze = raze;
    }

    /**
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * @return the hairtype
     */
    public String getHairtype() {
        return hairtype;
    }

    /**
     * @param hairtype the hairtype to set
     */
    public void setHairtype(String hairtype) {
        this.hairtype = hairtype;
    }
}



    
    
   