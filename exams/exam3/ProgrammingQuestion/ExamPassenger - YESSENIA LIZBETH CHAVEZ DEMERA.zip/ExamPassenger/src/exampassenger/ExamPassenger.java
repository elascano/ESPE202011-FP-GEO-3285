
package exampassenger;

/**
 *
 * @author Yessi
 */
public class ExamPassenger {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
