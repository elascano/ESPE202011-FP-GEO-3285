/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CodeNoteBook;

import javax.swing.JOptionPane;

/**
 *
 * @author Andres Ruiz
 */
public class CodeUtilNotebook {
    
    String data [][] = new String [40][50];
    
    void enterInfo(){
        
        int i = 0;
        
        if( i < data.length){
            String brand=String.valueOf(Menu_Notebook.brand.getText());
            String memory=String.valueOf(Menu_Notebook.memory.getText());
            String processor=String.valueOf(Menu_Notebook.processor.getText());
            String screen=String.valueOf(Menu_Notebook.screen.getText());
            String hdd=String.valueOf(Menu_Notebook.hdd.getText());
            
            data[i][0]=brand;
            data[i][1]=memory;
            data[i][2]=processor;
            data[i][3]=screen;
            data[i][4]=hdd;
            
            JOptionPane.showMessageDialog(null, "Data Saved Successfully");
        }else{
            JOptionPane.showMessageDialog(null, "INSUFFICIENT SPACE");
        }
    }
    void showInfo(){
            String rep = "Brand      |      Memory      |      Processor      |      Screen      |      Hdd\n";
            for(int j=0; j<data.length; j++){
            
                rep  +=  data[j][0] + "\t" + data[j][1] + "\t" + data[j][2] + "\t" + data[j][3] + "\t" + data[j][4] + "\n";
                Menu_Notebook.info.setText(rep);
                for(int i=0; i<data.length; i++){
                    if(data[i][j] == null){
                        data[i][j]="";
                }
            }
        }
 }
}