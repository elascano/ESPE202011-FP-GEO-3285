/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espe.jugueton.model;

/**
 *
 * @author Thomas Chavez
 */
public class Toy {
    private String name;
    private String color;
    private int age;
    private String type;

    public Toy(String name, String color, int age, String type) {
        this.name = name;
        this.color = color;
        this.age = age;
        this.type = type;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return the raze
     */
   

    public int getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * @return the hairtype
     */
    public String getType() {
        return type;
    }

    /**
     * @param hairtype the hairtype to set
     */
    public void setType(String type) {
        this.type = type;
    }
}
   

