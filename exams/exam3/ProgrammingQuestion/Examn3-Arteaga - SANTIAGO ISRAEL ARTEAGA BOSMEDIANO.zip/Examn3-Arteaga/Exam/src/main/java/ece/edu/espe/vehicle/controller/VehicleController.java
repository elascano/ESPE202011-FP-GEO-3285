/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ece.edu.espe.vehicle.controller;

import Utills.FileMananger;
import ece.edu.vehicle.model.Vehicle;

/**
 *
 * @author Usuario
 */
public class VehicleController {

    public void save(Vehicle vehicle) {
        String data = vehicle.getCost() + " , " + vehicle.getBrand() + " , " + vehicle.getChasis() + ", " + vehicle.getrin() + " , " + vehicle.getNumberOfdoor();
        FileMananger.save(data, "Vehicles");
    }

    public String read() {
        String data;
        data = FileMananger.read("Vehicles");
        return data;

    }
}
