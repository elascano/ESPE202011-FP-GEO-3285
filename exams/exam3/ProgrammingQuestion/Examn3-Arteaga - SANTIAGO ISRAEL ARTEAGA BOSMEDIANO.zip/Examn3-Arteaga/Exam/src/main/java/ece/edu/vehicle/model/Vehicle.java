/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ece.edu.vehicle.model;

/**
 *
 * @author Usuario
 */
public class Vehicle {
     private int cost;
    private String brand;
    private int chasis;
    private String rin;
    private String  numberOfdoor;

    public Vehicle(int cost, String brand, int year, String rin, String numberOfdoor) {
        this.cost = cost;
        this.brand = brand;
        this.chasis = year;
        this.rin =rin;
        this.numberOfdoor = numberOfdoor;
    }
    
    
    /**
     * @return the cost
     */
    public int getCost() {
        return cost;
    }

    /**
     * @param cost the cost to set
     */
    public void setCost(int cost) {
        this.cost = cost;
    }

    /**
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand the brand to set
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * @return the chasis
     */
    public int getChasis() {
        return chasis;
    }

    /**
     * @param chasis the chasis to set
     */
    public void setChasis(int chasis) {
        this.chasis = chasis;
    }

    /**
     * @return the rin
     */
    public String getrin() {
        return rin;
    }

    /**
     * @param rin the rin to set
     */
    public void setrin(String rin) {
        this.rin = rin;
    }

    /**
     * @return the numberOfdoor
     */
    public String getNumberOfdoor() {
        return numberOfdoor;
    }

    /**
     * @param numberOfdoor the numberOfdoor to set
     */
    public void setNumberOfdoor(String numberOfdoor) {
        this.numberOfdoor = numberOfdoor;
    }
    
    
}


