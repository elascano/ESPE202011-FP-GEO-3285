package ec.edu.espe.food.model;

public class Food {

    String Name;
    String Contry;
    String Availability;
    String Quality;
    int Price;

}
