/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vasconezjq11;

import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class VasconezJQ11 {

    /**
     * @param args the command line arguments
     */
    
    public static void main (String [] args){
    int add[] ={ 5,3,4,9,7};
    int total = 0;
    for (int contador =0; contador< add.length; contador ++){
            
    }
   {
   
   int numero, elementos = 0, suma=0;
   float media; 
   numero = Integer.parseInt(JOptionPane.showInputDialog("digite un numero"));
    
   while( numero>=0){
       suma += numero; 
       elementos++;
       numero =Integer.parseInt(JOptionPane.showInputDialog("digite el siguiente numero"));
       
   }
       }
    {
        
    
   
        // TODO code application logic here
    int a[]= {12, 23, 34, 98, 87, 65, 0};
        int b= 0;

        //    5    7     9           8     3     5       13    10    14
        //    9    5     8     +    -5     4    -3   =    4     9     5
        //    3    2     4           9    10    24       12    12    28
        
        int c[][] = new int[3][3];
        
        for(int i = 0 ; i < 3 ; i++){
            for (int j = 0 ; j < 3 ; j++) {
              
               
            }
        }
    }
}
}
