/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sandovalrebecaq11;

import java.util.Scanner;

/**
 *
 * @author Augusto
 */
public class SandovalRebecaQ11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
      Scanner input = new Scanner(System.in);
    boolean mainLoop = true;
    int option = 0;
    int i;
    i = 0;
    
    do{
        System.out.println("Enter the table that you want");
        System.out.println("Multiplication Tables : 6");       
        
            
                int top = 12;
                int product=0;
                int table = 6;
                for (int j = 1 ; j <= top ; j++){
                product = table * j;
                System.out.println("6 * " + j + " = " + product);
          }
                {
                    
        System.out.println("Enter the table that you want ->0");
                System.exit(0);              
    
                                                                                                                                                  
    }}while (option < 6);
        
                                                                             
       }       
    }  



           