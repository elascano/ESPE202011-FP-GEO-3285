int stop =12
int product;
System.out.prinln("tlable Multiplication");
System.out.prinln("enter value of the tabl" + " e multiplication");
table = input.nextInt();
System.out.prinln("table multiplication " + table );
for(int a=1;a <= stop; a++ ){
	product = table * a;
	System.out.prinln(table + "*" + a + "=" + product);
	
}
breack;
case 0:
System.out.prinln("good bay friends ");
 System.exit(0);
