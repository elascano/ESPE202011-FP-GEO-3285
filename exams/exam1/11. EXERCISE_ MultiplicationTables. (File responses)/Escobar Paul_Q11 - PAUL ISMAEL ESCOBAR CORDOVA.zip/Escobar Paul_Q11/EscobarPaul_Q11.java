
package escobarpaul_q11;

public class EscobarPaul_Q11 {
    public static void main(String[] args) {
     
    int option = 1; 
    int number_one = 6, mult= 1;
    int top = 12; 

    switch(option){
    case 1 : for(int multiplier = 1; multiplier <= 12; multiplier ++){

             System.out.println(number_one + " multiply to " +multiplier+ " the product is: "+ number_one*multiplier); 
             break;
            
   } default: System.out.println("Error la opcion no existe. ");
     break; 
  }  
 } 
} 

      

