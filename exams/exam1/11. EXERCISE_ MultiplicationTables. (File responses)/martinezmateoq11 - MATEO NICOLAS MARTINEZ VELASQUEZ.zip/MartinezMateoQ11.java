
package martinezmateoq11;

import java.util.Scanner;


public class MartinezMateoQ11 {


    public static void main(String[] args) {
        
         Scanner input = new Scanner(System.in);
        int option;

        do {
            System.out.println(" ========= Mathematical Operations =======");
            System.out.println("1. -> Table 1 ");
            System.out.println("2. -> Table 2");
            System.out.println("3. -> Table 3");
            System.out.println("4. -> Table 4");
              System.out.println("5. ->Table 5 ");
            System.out.println("6. -> Table 6");
            System.out.println("7. -> Table 7");
            System.out.println("8. -> Table 8");
              System.out.println("9. -> Table 9");
            System.out.println("10. -> Table 10");
            System.out.println("11. -> Table 11");
            ystem.out.println("12. -> Table 12");
         
            System.out.println("13. -> Exit");

            System.out.println("Enter your menu option --> ");
            option = input.nextInt();

            switch (option) {

                case 1:
          int multiply;
                    int multiplying;
                   int multiplier;
                   System.out.println("enter multiplying -> ");
                     multiplying = input.nextInt();
                    System.out.println("enter multiplier -> ");
                    multiplier = input.nextInt();
                   multiply = multiplying * multiplier;
                    System.out.println(" the multiply is --> " + multiply);
                    break;
        
    }
    
}
