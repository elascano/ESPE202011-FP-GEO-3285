/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elamalvarezq.pkg11;

import java.util.Scanner;

/**
 *
 * @author SAAVEDRA
 */
public class ElamAlvarezQ11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println("enter the table that you want to study");
        int top=12;
        int product =0;
        int table;
        table = imput.nexInt();
        for (int i = 1 ; i <= top ; i++){
            product = table * i;
            System.out.println(table + " *" + i + " = " + product);   
          
        }
        break;
        case 0:   
            System.out.println("Keep practicing see you later ");  
            System.exit(0);
            break;  
        default:
            System.out.println("Invalid option\n\n\n");
            break;
        }
              while (option != 5);
            
            
        }
        
        
        
    }
    

