/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vasconezjustinq11;

/**
 *
 * @author Usuario
 */
public class VasconezJustinQ11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
 int i;
 i=0;
  System.out.println("Multipication Tables :7");
                int top=12;
                int product=0;
                int table =6;
                for (int j =6 ;j<=top ; j++){
                    product = table*j;
                    System.out.println("6 *" + j + "=" + product);
                    
                }
    
    }
    
}
